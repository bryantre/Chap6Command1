public class IncrementStereoVolume implements Command {
	Stereo stereo;

	public IncrementStereoVolume(Stereo stereo) {
		this.stereo = stereo;
	}

	public void execute() {
		if (stereo.isOff == false) {
			stereo.setVolume(stereo.getVolume() + 1);
			System.out.println("Incrementing " + stereo.location 
				+ " stereo volume");
		}
	}
}
