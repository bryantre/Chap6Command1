public class DecrementStereoVolume implements Command {
	Stereo stereo;

	public DecrementStereoVolume(Stereo stereo) {
		this.stereo = stereo;
	}

	public void execute() {
		if (stereo.isOff == false) {
			stereo.setVolume(stereo.getVolume() - 1);
			System.out.println("Decrementing " + stereo.location 
				+ " stereo volume");
		}
	}
}
