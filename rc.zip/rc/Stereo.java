public class Stereo {
	String location;
	int volume;

	boolean beenTurnedOn;
	boolean isOff;

	public Stereo(String location) {
		this.location = location;
        beenTurnedOn = false;
        isOff = true;
    }

	public void on() {
        if (beenTurnedOn == false) {
			beenTurnedOn = true;
			setVolume(5);
		}
		else {
			setVolume(getVolume());
		}
		isOff = false;
		System.out.println(location + " stereo is on");
	}

	public void off() {
		isOff = true;
		System.out.println(location + " stereo is off");
	}

	public void setCD() {
		System.out.println(location + " stereo is set for CD input");
	}

	public void setDVD() {
		System.out.println(location + " stereo is set for DVD input");
	}

	public void setRadio() {
		System.out.println(location + " stereo is set for Radio");
	}

	public void setVolume(int volume) {
		// code to set the volume
		// valid range: 1-11 (after all 11 is better than 10, right?)
		if (volume < 1 || volume > 11) {
			System.out.println("Volume " + volume + " is not in the range 1-11");
		} else {
			System.out.println(location + " Stereo volume set to " + volume);
			this.volume = volume;
		}
	}

	public int getVolume() {
		return volume;
	}
}
