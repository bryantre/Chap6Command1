public interface Command {
	public void execute();
}
